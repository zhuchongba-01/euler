// src/background.ts
var isFirefox = typeof browser !== "undefined" && typeof browser.runtime !== "undefined";
if (isFirefox) {
  if (browser.browserAction) {
    browser.browserAction.onClicked.addListener(() => {
      if (browser.sidebarAction) {
        browser.sidebarAction.toggle();
      }
    });
  }
} else {
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id && chrome.sidePanel) {
      chrome.sidePanel.open({ tabId: tab.id });
    }
  });
}
//# sourceMappingURL=background.js.map
